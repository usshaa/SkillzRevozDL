#ifndef POINT_H
#define POINT_H

struct Point {
    double x = 0.;
    double z = 0.;
    Point() : x(0.), z(0.) {}
    Point(double _x, double _z) : x(_x), z(_z) {}
};


#endif // POINT_H
